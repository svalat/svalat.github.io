#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int main(int argc, char * argv[])
{
	//vars
	size_t size;
	char * buffer;
	int rank;
	int csize;
	double t0,t1;

	//init MPI
	MPI_Init(&argc,&argv);

	//check args
	if (argc != 2)
	{
		fprintf(stderr,"Missing arguments, usage : %s {SIZE}\n",argv[0]);
		return EXIT_FAILURE;
	} else {
		size = atol(argv[1]);
		assert(size > 0);
	}

	//allocate memory
	buffer = malloc(size);

	//get rank
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);

	//to exchange
	if (rank == 0)
	{
		t0 = MPI_Wtime();
		MPI_Send(buffer,size,MPI_CHAR,1,0,MPI_COMM_WORLD);
		MPI_Recv(buffer,size,MPI_CHAR,1,1,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		t1 = MPI_Wtime();
		printf("%lu	%g\n",size,t1-t0);
	}  else if (rank == 1 ) {
		MPI_Recv(buffer,size,MPI_CHAR,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		MPI_Send(buffer,size,MPI_CHAR,0,1,MPI_COMM_WORLD);
	} else {
		fprintf(stderr,"Invalid size, run only with '-np 2'\n");
		MPI_Abort(MPI_COMM_WORLD,1);
	}

	//clean memory
	free(buffer);

	//finish MPI
	MPI_Finalize();
}

