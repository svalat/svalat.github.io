#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define REPEAT (50000/s/s)

int main(int argc, char * argv[])
{
	//vars
	size_t size;
	char * buffer;
	int rank;
	int csize;
	double t0,t1;
	unsigned long i;
	int s;

	//init MPI
	MPI_Init(&argc,&argv);

	//check args
	if (argc != 1)
	{
		fprintf(stderr,"Invalid arguments, usage : %s\n",argv[0]);
		return EXIT_FAILURE;
	}

	for ( s = 5 ; s < 34 ; s++)
	{
		//allocate memory
		size = 1 << s;
		buffer = malloc(size);

		//get rank
		MPI_Comm_rank(MPI_COMM_WORLD,&rank);

		//wait all
		MPI_Barrier(MPI_COMM_WORLD);

		//to exchange
		if (rank == 0)
		{
			t0 = MPI_Wtime();
			for ( i = 0 ; i < REPEAT ; i++)
			{
				MPI_Send(buffer,size,MPI_CHAR,1,0,MPI_COMM_WORLD);
				MPI_Recv(buffer,size,MPI_CHAR,1,1,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
			}
			t1 = MPI_Wtime();
			printf("%lu     %g\n",size,(t1-t0)/(double)(REPEAT));
		}  else if (rank == 1 ) {
			for (i = 0 ; i < REPEAT ; i++)
			{
				MPI_Recv(buffer,size,MPI_CHAR,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
				MPI_Send(buffer,size,MPI_CHAR,0,1,MPI_COMM_WORLD);
			}
		} else {
			fprintf(stderr,"Invalid size, run only with '-np 2'\n");
			MPI_Abort(MPI_COMM_WORLD,1);
		}

		//clean memory
		free(buffer);
	}

	//finish MPI
	MPI_Finalize();
}

