#!/bin/bash

echo "================ -O0 seq ================"
./tp6-ex1-0
echo "================ -O3 seq ================"
./tp6-ex1-1
echo "============ -O3 OMP nolocks ============"
OMP_NUM_THREADS=1 ./tp6-ex1-2
./tp6-ex1-2
echo "============ -O3 OMP critical ==========="
OMP_NUM_THREADS=1 ./tp6-ex1-3
./tp6-ex1-3
echo "============ -O3 OMP atomic ============="
OMP_NUM_THREADS=1 ./tp6-ex1-4
./tp6-ex1-4
echo "========= -O3 OMP false sharing ========="
OMP_NUM_THREADS=1 ./tp6-ex1-5
./tp6-ex1-5
echo "========= -O3 OMP false padding ========="
OMP_NUM_THREADS=1 ./tp6-ex1-6
./tp6-ex1-6
echo "============ -O3 OMP atomic read ========"
OMP_NUM_THREADS=1 ./tp6-ex1-7
./tp6-ex1-7
echo "============== -O3 OMP reduce ==========="
OMP_NUM_THREADS=1 ./tp6-ex1-8
./tp6-ex1-8