//Pour malloc et EXIT_SUCCESS
#include <stdlib.h>
//Pour memset
#include <string.h>
//Pour printf
#include <stdio.h>
//Pour avoir omp_get_num_threads et omp_get_thread_num
#include <omp.h>
//Pout getticks (tiré de fftw)
#include "cycle.h"

int main(int argc, char * argv[])
{
	//vars
	ticks t0,t1;
	//on tache de choisir une taille entrant dans les caches pour mieux voir le problème
	const unsigned int size = SIZE / sizeof(int);
	const unsigned int repeat = 1;
	unsigned int i,j;
	int sum = 0.0;
	int * values = malloc(size*sizeof(int));

	//some info
	#pragma omp parallel
	#pragma omp single
	printf("Threads : %d\n",omp_get_num_threads());

	//init mem
    for(i = 0 ; i < size ; i++)
        values[i] = i;

	//start time
	t0 = getticks();

	//loop
	for (j = 0 ; j < repeat ; j++)
	{
		sum = 0;
		#pragma omp parallel for
		for(i = 0 ; i < size ; i++)
		{
			#pragma omp critical
			sum += values[i];
		}
	}

	//end
	t1 = getticks();

	//print res
	printf("Sum = %d , Time : %f\n",sum,((float)(t1-t0))/(float)(repeat * size));

	//finish OK
	return EXIT_SUCCESS;
}
