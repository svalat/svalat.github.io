//Pour malloc et EXIT_SUCCESS
#include <stdlib.h>
//Pour memset
#include <string.h>
//Pour printf
#include <stdio.h>
//Pour avoir omp_get_num_threads et omp_get_thread_num
#include <omp.h>
//Pour assert
#include <assert.h>
//Pout getticks (tiré de fftw)
#include "cycle.h"

int main(int argc, char * argv[])
{
	//vars
	ticks t0,t1;
	//on tache de choisir une taille entrant dans les caches pour mieux voir le problème
	const unsigned int size = SIZE / sizeof(int);
	const unsigned int repeat = 1;
	unsigned int i,j;
	int sum = 0.0;
	int * values = malloc(size*sizeof(int));
	int sums[1024];
	int threads;

	//some info
	#pragma omp parallel
	#pragma omp single
	threads = omp_get_num_threads();
	printf("Threads : %d\n",threads);
	assert(threads < 1024);

	//init mem
    for(i = 0 ; i < size ; i++)
        values[i] = i;
	for (i = 0 ; i < threads ; i++)
		sums[i] = 0;

	//start time
	t0 = getticks();

	//loop
	for (j = 0 ; j < repeat ; j++)
	{
		sum = 0;
		for (i = 0 ; i < threads ; i++)
			sums[i] = 0;

		#pragma omp parallel
		{
			int id = omp_get_thread_num();
			#pragma omp for
			for(i = 0 ; i < size ; i++)
				sums[id] += values[i];
		}
		
		//aggregate
		for (i = 0 ; i < threads ; i++)
			sum += sums[i];
	}

	//end
	t1 = getticks();

	//print res
	printf("Sum = %d , Time : %f\n",sum,((float)(t1-t0))/(float)(repeat * size));

	//finish OK
	return EXIT_SUCCESS;
}
